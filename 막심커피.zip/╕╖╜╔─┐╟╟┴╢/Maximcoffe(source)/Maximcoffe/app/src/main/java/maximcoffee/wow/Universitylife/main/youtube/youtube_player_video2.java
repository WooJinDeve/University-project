package maximcoffee.wow.Universitylife.main.youtube;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import maximcoffee.wow.Universitylife.R;

public class youtube_player_video2 extends YouTubeBaseActivity {

    //유튜브 호출
    YouTubePlayerView youTubeView;
    Button button;
    YouTubePlayer.OnInitializedListener listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_2);

        //탭 호출 2
//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab_youtube);
//        assert fab != null;
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent launchIntent = new Intent(getBaseContext(), CreateScheduleActivity.class);
//                startActivity(launchIntent);
//            }
//        });


        button = (Button) findViewById(R.id.youtubeButton);
        youTubeView = (YouTubePlayerView) findViewById(R.id.youtubeView);
        listener = new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
                youTubePlayer.loadVideo("4V4KvoxoB5c"); // 유튜브 링크

            }


            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {

            }
        };

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //개인 유튜브 API 호출
                youTubeView.initialize("AIzaSyAbhnDM8l7k159zTij84f-slaQgp3je_e0", listener);
            }
        });
    }
}