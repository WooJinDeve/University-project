package maximcoffee.wow.Universitylife.main.youtube;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import java.util.ArrayList;

import maximcoffee.wow.Universitylife.R;

public class youtube_player extends YouTubeBaseActivity {


    YouTubePlayerView youTubeView;
    Button button;
    YouTubePlayer.OnInitializedListener listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youtube);

        Button youtubeButton = (Button) findViewById(R.id.youtubeButton);

        youtubeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(youtube_player.this, youtube_player_video.class);
                startActivity(intent);
            }
        });

        Button youtubeButton2 = (Button) findViewById(R.id.youtubeButton2);

        youtubeButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(youtube_player.this, youtube_player_video2.class);
                startActivity(intent);
            }
        });

        Button youtubeButton3 = (Button) findViewById(R.id.youtubeButton3);

        youtubeButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(youtube_player.this, youtube_player_video3.class);
                startActivity(intent);
            }
        });
    }
}