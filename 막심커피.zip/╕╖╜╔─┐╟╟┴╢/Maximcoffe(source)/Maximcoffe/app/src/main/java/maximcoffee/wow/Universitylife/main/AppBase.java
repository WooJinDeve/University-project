package maximcoffee.wow.Universitylife.main;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.GridView;

import java.util.ArrayList;

import maximcoffee.wow.Universitylife.R;
import maximcoffee.wow.Universitylife.main.components.About;
import maximcoffee.wow.Universitylife.main.components.GridAdapter;
import maximcoffee.wow.Universitylife.main.components.SettingsActivity;
import maximcoffee.wow.Universitylife.main.database.DatabaseHandler;



public class AppBase extends AppCompatActivity {

    public static ArrayList<String> divisions;
    public static DatabaseHandler handler;
    public static Activity activity;
    ArrayList<String> basicFields;
    GridAdapter adapter;
    GridView gridView;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mai_menu, menu);
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_layout);
        basicFields = new ArrayList<>();
        handler = new DatabaseHandler(this);
        activity = this;

        getSupportActionBar().show();
        divisions = new ArrayList<>();
        divisions.add("1교시");
        divisions.add("2교시");
        divisions.add("3교시");
        divisions.add("4교시");
        divisions.add("5교시");
        divisions.add("6교시");
        divisions.add("7교시");
        divisions.add("8교시");
        gridView = (GridView) findViewById(R.id.grid);
        basicFields.add("ATTENDANCE");
        basicFields.add("SCHEDULER");
        basicFields.add("NOTES");
        basicFields.add("COLLEGE CREDIT");
        basicFields.add("CALCULATOR");
        basicFields.add("YOUTUBE");
        basicFields.add("FOOD MAP");
        basicFields.add("RECORDER");
        adapter = new GridAdapter(this, basicFields);
        gridView.setAdapter(adapter);
    }

    public void loadSettings(MenuItem item) {
        Intent launchIntent = new Intent(this, SettingsActivity.class);
        startActivity(launchIntent);
    }

    public void loadAbout(MenuItem item) {
        Intent launchIntent = new Intent(this, About.class);
        startActivity(launchIntent);
    }
}
