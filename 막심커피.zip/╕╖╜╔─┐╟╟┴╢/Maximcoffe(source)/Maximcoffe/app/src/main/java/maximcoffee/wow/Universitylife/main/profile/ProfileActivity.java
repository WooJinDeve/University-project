package maximcoffee.wow.Universitylife.main.profile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import maximcoffee.wow.Universitylife.R;
import maximcoffee.wow.Universitylife.main.AppBase;
import maximcoffee.wow.Universitylife.main.database.DatabaseHandler;

public class ProfileActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    String num1,num2,num3,num4,num5,num6,num7;

    Integer result3,result1;
    Integer num = 7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stu_profile);

        Spinner spinner1 = findViewById(R.id.grade1);
        Spinner spinner2 = findViewById(R.id.grade2);
        Spinner spinner3 = findViewById(R.id.grade3);
        Spinner spinner4 = findViewById(R.id.grade4);
        Spinner spinner5 = findViewById(R.id.grade5);
        Spinner spinner6 = findViewById(R.id.grade6);
        Spinner spinner7 = findViewById(R.id.grade7);


        final Button btn1 = (Button) findViewById(R.id.btn1);

        final EditText Score1 = (EditText) findViewById(R.id.score1);
        final EditText Score2 = (EditText) findViewById(R.id.score2);
        final EditText Score3 = (EditText) findViewById(R.id.score3);
        final EditText Score4 = (EditText) findViewById(R.id.score4);
        final EditText Score5 = (EditText) findViewById(R.id.score5);
        final EditText Score6 = (EditText) findViewById(R.id.score6);
        final EditText Score7 = (EditText) findViewById(R.id.score7);


        final CheckBox major1 = (CheckBox) findViewById(R.id.major1);
        final CheckBox major2 = (CheckBox) findViewById(R.id.major2);
        final CheckBox major3 = (CheckBox) findViewById(R.id.major3);
        final CheckBox major4 = (CheckBox) findViewById(R.id.major4);
        final CheckBox major5 = (CheckBox) findViewById(R.id.major5);
        final CheckBox major6 = (CheckBox) findViewById(R.id.major6);
        final CheckBox major7 = (CheckBox) findViewById(R.id.major7);


        final TextView text1 = (TextView) findViewById(R.id.text1);
        final TextView text2 = (TextView) findViewById(R.id.text2);
        final TextView text3 = (TextView) findViewById(R.id.text3);
        final TextView text4 = (TextView) findViewById(R.id.text4);



        btn1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                btn1.setVisibility(View.INVISIBLE);
                text1.setVisibility(View.VISIBLE);
                text2.setVisibility(View.VISIBLE);
                text3.setVisibility(View.VISIBLE);
                text4.setVisibility(View.VISIBLE);

                final Integer[] result4 = {0};


                num1 = Score1.getText().toString();
                num2 = Score2.getText().toString();
                num3 = Score3.getText().toString();
                num4 = Score4.getText().toString();
                num5 = Score5.getText().toString();
                num6 = Score6.getText().toString();
                num7 = Score7.getText().toString();
                result3 = Integer.parseInt(num1)+Integer.parseInt(num2)+Integer.parseInt(num3)+Integer.parseInt(num4)+Integer.parseInt(num5)+Integer.parseInt(num6)+Integer.parseInt(num7);

                result1 = result3/num;
                text1.setText("총 평점 : " + result1.toString());
                text3.setText("이수학점 : " +result3.toString());
                return false;
            }
        });


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource( this, R.array.numbers, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);
        spinner1.setOnItemSelectedListener((AdapterView.OnItemSelectedListener)this);
        spinner2.setAdapter(adapter);
        spinner2.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        spinner3.setAdapter(adapter);
        spinner3.setOnItemSelectedListener((AdapterView.OnItemSelectedListener)this);
        spinner4.setAdapter(adapter);
        spinner4.setOnItemSelectedListener((AdapterView.OnItemSelectedListener)this);
        spinner5.setAdapter(adapter);
        spinner5.setOnItemSelectedListener((AdapterView.OnItemSelectedListener)this);
        spinner6.setAdapter(adapter);
        spinner6.setOnItemSelectedListener((AdapterView.OnItemSelectedListener)this);
        spinner7.setAdapter(adapter);
        spinner7.setOnItemSelectedListener((AdapterView.OnItemSelectedListener)this);
    }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
