#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <Windows.h>

char str_[20]; // ���ڿ� ��ȯ �Լ� ����� ���� �������� ��� 

int main(void) 
{
	CDListNode* chead = (CDListNode*)malloc(sizeof(CDListNode));
	PDListNode* phead = (PDListNode*)malloc(sizeof(PDListNode));
	PDListNode* p_cur;
	CDListNode* c_cur;

	char ch1 = '1';
	char ch2 = '1';

	init(chead, phead);
	Company_Fileprint(chead);
	People_Fileprint(phead);

	while (1)
	{
		system("cls");
		char ch = basic_menuprint();
		switch (ch)
		{
		case '1': p_cur = P_login(phead);
			if (p_cur != NULL)
			{
				while (ch1 != '0') {
					system("cls");
					ch1 = people_menuprint();
					switch (ch1)
					{
						case '1': Print_People(p_cur); break;
						case '2': Set_People(p_cur); break;
						case '3': Matching_company(chead, p_cur->p_data,1);   company_url(); break;
						case '4': Matching_company(chead, p_cur->p_data, 0);  company_url(); break;
						case '5': select_Company(chead); break;
						case '6': Company_PrintAll(chead); break;
						case '7': if (People_delete(phead, p_cur) == 1) break;
						case '8': People_Save(phead); ch1 = '0'; 
					}
					system("pause");
				}
				ch1 = '1';
			}	break;
		case '2': c_cur = C_login(chead);
			if (c_cur != NULL)
			{
				while (ch2 != '0') {
					system("cls");
					ch2 = company_menuprint();
					switch (ch2)
					{
						case '1': Company_Print(c_cur); break;
						case '2': Set_Company(c_cur); break;
						case '3': select_Company(chead); break;
						case '4': Company_PrintAll(chead); break;
						case '5': if (Company_delete(chead, c_cur) == 1) break;
						case '6': Company_Save(chead); ch2 = '0';
					}
					system("pause");
				}
				ch2 = '1';
			} break;
		case '3': membership(chead, phead); break;
		case '4': select_Company(chead); break;
		case '5': Company_PrintAll(chead); break;
		case '6': Company_Save(chead); People_Save(phead); return;
		}
		system("pause");
	}

	free(chead);
	free(phead);
	return 0;
}